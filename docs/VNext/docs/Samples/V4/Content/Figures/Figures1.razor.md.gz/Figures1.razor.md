﻿<BSFigure>
    <BSImage Source="400x300" IsRounded="true" IsFluid="true" IsPlaceholder="true" />
    <BSFigureCaption>A caption for the above image.</BSFigureCaption>
</BSFigure>