﻿<div Class="@BS.Text_Center">
    <BSImage Source="200x200" IsFluid="true" IsThumbnail="true" IsPlaceholder="true"/>
</div>