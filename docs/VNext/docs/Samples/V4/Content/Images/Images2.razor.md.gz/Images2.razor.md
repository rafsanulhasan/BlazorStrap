﻿<!-- Width Set so high for the demo -->
<BSImage Source="200x200" IsFluid="true" IsThumbnail="true"  IsPlaceholder="true"/>