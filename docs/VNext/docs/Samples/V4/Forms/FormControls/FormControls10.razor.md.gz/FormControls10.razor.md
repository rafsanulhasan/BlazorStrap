﻿<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">Text</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Text" @bind-Value="TextValue" ValidateOnInput="true" />
    <BSInputGroup IsPrepend="true" IsAppend="true">
        <span class="input-group-text">Password</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Password" @bind-Value="TextValue" />
    <BSInputGroup IsPrepend="true" IsAppend="true">
        <span class="input-group-text">Email</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Email" @bind-Value="TextValue" />
    <BSInputGroup IsPrepend="true" IsAppend="true">
        <span class="input-group-text">Value = @TextValue</span>
    </BSInputGroup>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">DateTimeLocal As DateTime</span>
    </BSInputGroup>
    <BSInput InputType="InputType.DateTimeLocal" @bind-Value="DateValue" />
    <BSInputGroup IsAppend="true">
        <span class="input-group-text">Value = @DateValue</span>
    </BSInputGroup>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">DateTimeLocal As DateTimeOffset</span>
    </BSInputGroup>
    <BSInput InputType="InputType.DateTimeLocal" @bind-Value="DateOffsetValue" />
    <BSInputGroup IsAppend="true">
        <span class="input-group-text">Value = @DateOffsetValue</span>
    </BSInputGroup>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">Date As DateTime</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Date" @bind-Value="DateValue" />
    <BSInputGroup IsAppend="true">
        <span class="input-group-text">Value = @DateValue</span>
    </BSInputGroup>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">Date As DateTimeOffset</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Date" @bind-Value="DateOffsetValue" />
    <BSInputGroup IsAppend="true">
        <span class="input-group-text">Value = @DateOffsetValue</span>
    </BSInputGroup>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">Month As DateOnly</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Date" @bind-Value="DateOnlyValue" />
    <BSInputGroup IsAppend="true">
        <span class="input-group-text">Value = @DateOnlyValue</span>
    </BSInputGroup>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="input-group-text">Time As TimeOnly</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Time" @bind-Value="TimeOnlyValue" />
    <BSInputGroup IsAppend="true">
        <span class="input-group-text">Value = @TimeOnlyValue</span>
    </BSInputGroup>
</BSInputGroup>

@code {
    private string? TextValue { get; set; }
    private DateTime DateValue { get; set; }
    private DateTimeOffset DateOffsetValue { get; set; }
    private TimeOnly TimeOnlyValue { get; set; }
    private DateOnly DateOnlyValue { get; set; }
}