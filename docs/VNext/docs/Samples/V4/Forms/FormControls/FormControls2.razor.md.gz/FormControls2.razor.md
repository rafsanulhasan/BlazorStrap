﻿<BSInput InputType="InputType.Text" InputSize="Size.Large" placeholder=".form-control-lg" Value="@("")"/>
<BSInput InputType="InputType.Text" placeholder="Default input" Value="@("")"/>
<BSInput InputType="InputType.Text" InputSize="Size.Small" placeholder=".form-control-sm" Value="@("")"/>