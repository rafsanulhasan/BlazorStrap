﻿<BSRow MarginBottom="Margins.Medium">
    <BSLabel IsColumn="true">Email address</BSLabel>
    <BSCol ColumnSmall="10">
        <BSInput InputType="InputType.Email" Value="@("name@example.com")" IsPlainText="true"/>
    </BSCol>
</BSRow>
<BSRow MarginBottom="Margins.Medium">
    <BSLabel IsColumn="true">Password</BSLabel>
    <BSCol ColumnSmall="10">
        <BSInput InputType="InputType.Password" Value="@("")"/>
    </BSCol>
</BSRow>