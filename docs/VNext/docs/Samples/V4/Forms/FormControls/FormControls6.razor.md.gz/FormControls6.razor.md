﻿<BSForm IsRow="true" Gutters="Gutters.Medium" IsBasic="true">
    <BSCol Column="auto">
        <BSLabel IsHidden="true">Email</BSLabel>
        <BSInput InputType="InputType.Email" placeholder="name@example.com" IsPlainText="true" Value="@("email@example.com")"/>
    </BSCol>
    <BSCol Column="auto">
        <BSLabel IsHidden="true">Password</BSLabel>
        <BSInput InputType="InputType.Password" Value="@("")"/>
    </BSCol>
    <BSCol Column="auto">
        <BSButton Color="BSColor.Primary" IsSubmit="true" MarginBottom="Margins.Medium">Confirm identity</BSButton>
    </BSCol>
</BSForm>