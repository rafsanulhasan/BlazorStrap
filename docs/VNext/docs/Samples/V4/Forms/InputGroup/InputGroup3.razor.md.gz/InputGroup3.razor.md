﻿<BSInputGroup Size="Size.Small" MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="@BS.Input_Group_Text">Small</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Text" Value="@("")" />
</BSInputGroup>

<BSInputGroup Size="Size.Medium" MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="@BS.Input_Group_Text">Medium</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Text" Value="@("")" />
</BSInputGroup>

<BSInputGroup Size="Size.Large" MarginBottom="Margins.Medium">
    <BSInputGroup IsPrepend="true">
        <span class="@BS.Input_Group_Text">Large</span>
    </BSInputGroup>
    <BSInput InputType="InputType.Text" Value="@("")" />
</BSInputGroup>