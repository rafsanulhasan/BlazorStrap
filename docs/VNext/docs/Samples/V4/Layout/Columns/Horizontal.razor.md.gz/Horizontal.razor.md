﻿<BSContainer>
    <BSRow Justify="Justify.Start">
        <BSCol Column="4">
            One of two columns
        </BSCol>
        <BSCol Column="4">
            One of two columns
        </BSCol>
    </BSRow>
    <BSRow Justify="Justify.Center">
        <BSCol Column="4">
            One of two columns
        </BSCol>
        <BSCol Column="4">
            One of two columns
        </BSCol>
    </BSRow>
    <BSRow Justify="Justify.End">
        <BSCol Column="4">
            One of two columns
        </BSCol>
        <BSCol Column="4">
            One of two columns
        </BSCol>
    </BSRow>
    <BSRow Justify="Justify.Around">
        <BSCol Column="4">
            One of two columns
        </BSCol>
        <BSCol Column="4">
            One of two columns
        </BSCol>
    </BSRow>
    <BSRow Justify="Justify.Between">
        <BSCol Column="4">
            One of two columns
        </BSCol>
        <BSCol Column="4">
            One of two columns
        </BSCol>
    </BSRow>
</BSContainer>