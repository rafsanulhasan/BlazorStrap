﻿<BSContainer>
    <BSRow>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
        <!-- Force next columns to break to new line at md breakpoint and up -->
        <div class="w-100 d-none d-md-block"></div>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
    </BSRow>
</BSContainer> 