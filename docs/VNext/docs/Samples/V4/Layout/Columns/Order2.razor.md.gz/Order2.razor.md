﻿<BSContainer>
    <BSRow>
        <BSCol OrderLast="true">
            First in DOM, ordered last
        </BSCol>
        <BSCol>
            Second in DOM, unordered
        </BSCol>
        <BSCol OrderFirst="true">
            Third in DOM, ordered first
        </BSCol>
    </BSRow>
</BSContainer>