﻿<h1>Example heading <BSBadge Color="BSColor.Secondary">New</BSBadge></h1>
<h2>Example heading <BSBadge Color="BSColor.Secondary">New</BSBadge></h2>
<h3>Example heading <BSBadge Color="BSColor.Secondary">New</BSBadge></h3>
<h4>Example heading <BSBadge Color="BSColor.Secondary">New</BSBadge></h4>
<h5>Example heading <BSBadge Color="BSColor.Secondary">New</BSBadge></h5>
<h6>Example heading <BSBadge Color="BSColor.Secondary">New</BSBadge></h6>