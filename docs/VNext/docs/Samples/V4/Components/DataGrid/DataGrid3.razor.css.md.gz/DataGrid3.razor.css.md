﻿::deep .bs-datagrid {
    height: 20rem;
    overflow-y: auto;
}

::deep .bs-datagrid table{
    min-width: 100%;
}
::deep .bs-datagrid tr {
    height: 30px;
}
::deep .bs-datagrid td {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    width: 50px !important;
}