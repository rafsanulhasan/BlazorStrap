﻿<BSCollapse>
    <Toggler><BSToggle IsButton="true" Color="BSColor.Primary">Toggler</BSToggle></Toggler>
    <Content>
        <BSCard CardType="CardType.Card">
            The button is placed outside of the collapses when rendering.
        </BSCard>
    </Content>
</BSCollapse>