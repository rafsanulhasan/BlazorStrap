<BSSpinner Size="Size.Small"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Size="Size.Small"/>