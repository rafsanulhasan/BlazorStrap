﻿<BSAlert Color="BSColor.Primary">A simple primary alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Secondary">A simple secondary alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Success">A simple success alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Danger">A simple danger alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Warning">A simple warning alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Info">A simple info alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Light">A simple light alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>
<BSAlert Color="BSColor.Dark">A simple dark alert with <BSAlertLink Url="javascript:void();">with an example link</BSAlertLink></BSAlert>