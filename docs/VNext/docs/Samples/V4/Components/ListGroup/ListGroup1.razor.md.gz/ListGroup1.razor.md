﻿<BSListGroup>
    <BSListGroupItem>An Item</BSListGroupItem>
    <BSListGroupItem>An item</BSListGroupItem>
    <BSListGroupItem>A second item</BSListGroupItem>
    <BSListGroupItem>A third item</BSListGroupItem>
    <BSListGroupItem>A fourth item</BSListGroupItem>
    <BSListGroupItem>And a fifth one</BSListGroupItem>
</BSListGroup>