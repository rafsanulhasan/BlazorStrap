<!--\\-->
@using BlazorStrap_Docs.SampleModels
<!--//-->

<BSDropdown Demo="true">
    <Content>
        <BSForm Model="model" Class="px-4 py-3">
            <div class="mb-3">
                <BSLabel for="exampleDropdownFormEmail1">Email address</BSLabel>
                <BSInput InputType="InputType.Email" @bind-Value="model.Email" id="exampleDropdownFormEmail1" placeholder="email@example.com"/>
            </div>
            <div class="mb-3">
                <BSLabel for="exampleDropdownFormPassword1">Email address</BSLabel>
                <BSInput InputType="InputType.Password" @bind-Value="model.Password" id="exampleDropdownFormPassword1" placeholder="Password"/>
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <BSInputCheckbox @bind-Value="model.RememberMe" id="RememberMeCheck"/>
                    <BSLabel for="RememberMeCheck">Remember me</BSLabel>
                </div>
            </div>
            <BSButton Color="BSColor.Primary" >Sign In</BSButton>
        </BSForm>
        <BSDropdownItem IsDivider="true" />
        <BSDropdownItem>New around here? Sign up</BSDropdownItem>
        <BSDropdownItem>Forgot password?</BSDropdownItem>
    </Content>
</BSDropdown>

@code {
    private DropdownFormModel model = new DropdownFormModel();
}