<BSButtonGroup DropdownPlacement="Placement.RightStart">
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary" >Dropright</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup DropdownPlacement="Placement.RightStart">
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Secondary">Split dropright</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Secondary" IsSplitButton="true"><span class="visually-hidden">Toggle Dropdown</span></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>