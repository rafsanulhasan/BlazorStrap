<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary" Size="Size.Large">Large button</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Secondary" Size="Size.Large">Large split button</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Secondary" Size="Size.Large"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>