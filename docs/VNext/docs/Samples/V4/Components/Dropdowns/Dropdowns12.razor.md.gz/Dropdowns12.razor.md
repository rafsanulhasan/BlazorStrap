<BSDropdown>
    <Toggler>
        <BSToggle IsButton="true" Color="BSColor.Secondary">Dropdown</BSToggle>
    </Toggler>
    <Content>
        <BSDropdownItem IsButton="true">Action</BSDropdownItem>
        <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
        <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
    </Content>
</BSDropdown>