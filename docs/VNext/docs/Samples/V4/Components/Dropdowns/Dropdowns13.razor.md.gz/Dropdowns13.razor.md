<BSDropdown Demo="true">
    <Content>
        <BSDropdownItem IsText="true">Dropdown item text</BSDropdownItem>
        <BSDropdownItem>Action</BSDropdownItem>
        <BSDropdownItem>Another action</BSDropdownItem>
        <BSDropdownItem>Something else here</BSDropdownItem>
    </Content>
</BSDropdown>