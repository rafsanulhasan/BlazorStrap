<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary" Size="Size.Small">Small button</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Secondary" Size="Size.Small">Small split button</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Secondary" Size="Size.Small"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>