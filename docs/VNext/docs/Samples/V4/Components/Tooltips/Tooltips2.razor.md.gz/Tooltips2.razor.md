﻿<BSButton Color="BSColor.Secondary" DataId="set2topTooltip">Tooltip on top</BSButton>
<BSTooltip Placement="Placement.Top" Target="set2topTooltip" ContentAlwaysRendered="true">Tooltip on top</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="set2rightTooltip">Tooltip on right</BSButton>
<BSTooltip Placement="Placement.Right" Target="set2rightTooltip" ContentAlwaysRendered="true">Tooltip on right</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="set2bottomTooltip">Tooltip on bottom</BSButton>
<BSTooltip Placement="Placement.Bottom" Target="set2bottomTooltip" ContentAlwaysRendered="true">Tooltip on bottom</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="set2leftTooltip">Tooltip on left</BSButton>
<BSTooltip Placement="Placement.Left" Target="set2leftTooltip">Tooltip on left</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="set2htmlTooltip">Tooltip with HTML</BSButton>
<BSTooltip Placement="Placement.Top" Target="set2htmlTooltip" ContentAlwaysRendered="true"><em>Tooltip</em> <u>with</u> <b>HTML</b></BSTooltip>