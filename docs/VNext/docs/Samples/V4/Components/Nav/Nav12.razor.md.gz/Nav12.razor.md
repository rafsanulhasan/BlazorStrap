﻿<BSNav IsTabs="true">
    <BSNavItem IsActive="true">Active</BSNavItem>
    <BSNavItem IsDropdown="true">
        <BSDropdown>
            <Toggler><BSToggle IsNavLink="true">Dropdown</BSToggle></Toggler>
            <Content>
                <BSDropdownItem Url="javascript:void(0);">Action</BSDropdownItem>
                <BSDropdownItem Url="javascript:void(0);">Another action</BSDropdownItem>
                <BSDropdownItem Url="javascript:void(0);">Something else here</BSDropdownItem>
                <BSDropdownItem IsDivider="true"/>
                <BSDropdownItem Url="javascript:void(0);">Separated link</BSDropdownItem>
            </Content>
        </BSDropdown>
    </BSNavItem>
    <BSNavItem>Link</BSNavItem>
    <BSNavItem IsDisabled="true">Disabled</BSNavItem>
</BSNav>