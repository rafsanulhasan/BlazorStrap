﻿<BSNavbar Color="BSColor.Light" IsStickyTop="true">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Sticky top</BSNavbarBrand>
    </BSContainer>
</BSNavbar>