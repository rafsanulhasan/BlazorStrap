﻿<BSNavbar Color="BSColor.Light" IsFixedBottom="true">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Fixed bottom</BSNavbarBrand>
    </BSContainer>
</BSNavbar>