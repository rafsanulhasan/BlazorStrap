﻿<BSNavbar Color="BSColor.Light">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand Url="javascript:void(0);">
            <img src="logo.svg" width="30" class="d-inline-block align-text-top"/>
            BlazorStrap
        </BSNavbarBrand>
    </BSContainer>
</BSNavbar>