﻿<!-- As a Link -->
<BSNavbar Color="BSColor.Light">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand Url="javascript:void(0);">Navbar</BSNavbarBrand>
    </BSContainer>
</BSNavbar>

<!-- As a heading -->
<BSNavbar Color="BSColor.Light">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand Class="mb-0 h1">Navbar</BSNavbarBrand>
    </BSContainer>
</BSNavbar>