﻿<!--The space in the divier is used only to make the syntax hightlighting work correctly you can just use ""-->
<BSBreadcrumb Divider=" ">
    <BSBreadcrumbItem Url="javascript:void(0);">Home</BSBreadcrumbItem>
    <BSBreadcrumbItem IsActive="true">Library</BSBreadcrumbItem>
</BSBreadcrumb>