﻿<BSTree IsExpanded="true">
    <BSTreeNode>
        <BSTreeItem>
            <Label>Level 1-a</Label>
            <ChildContent>
                <BSTreeNode>
                    <BSTreeItem>
                        <Label>Level 2-a</Label>
                    </BSTreeItem>
                    <BSTreeItem IsDefaultActive="true">
                        <Label>Level 2-b</Label>
                    </BSTreeItem>
                    <BSTreeItem TextLabel="Level 2-c">
                        <BSTreeNode>
                            <BSTreeItem TextLabel="Level 3-a"/>
                            <BSTreeItem TextLabel="Level 3-b"/>
                            <BSTreeItem TextLabel="Level 3-c">
                                <Action>With Action links</Action>
                            </BSTreeItem>
                        </BSTreeNode>
                    </BSTreeItem>
                </BSTreeNode>
            </ChildContent>
        </BSTreeItem>
        <BSTreeItem>
            <Label>Level 1-b</Label>
        </BSTreeItem>
        <BSTreeItem>
            <Label>Level 1-c</Label>
        </BSTreeItem>
    </BSTreeNode>
</BSTree>