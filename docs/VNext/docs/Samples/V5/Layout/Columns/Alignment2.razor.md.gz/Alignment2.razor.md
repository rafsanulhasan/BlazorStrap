﻿<BSContainer>
    <BSRow>
        <BSCol Align="Align.Start">
            One of three columns
        </BSCol>
        <BSCol Align=Align.Center>
            One of three columns
        </BSCol>
        <BSCol Align=Align.End>
            One of three columns
        </BSCol>
    </BSRow>
</BSContainer>
