﻿<BSContainer>
    <BSRow>
        <BSCol Column="9">Column="9"</BSCol>
        <BSCol Column="4">Column="4"<br />Since 9 + 4 = 13 &gt; 12, this 4-column-wide div gets wrapped onto a new line as one contiguous unit.</BSCol>
        <BSCol Column="6">Column="6"<br />Subsequent columns continue along the new line.</BSCol>
    </BSRow>
</BSContainer>