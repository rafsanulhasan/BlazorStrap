﻿<BSNav IsPills="true" IsFill="true" IsJustified="true">
    <BSNavItem IsActive="true">Active</BSNavItem>
    <BSNavItem>Much longer nav link</BSNavItem>
    <BSNavItem>Link</BSNavItem>
    <BSNavItem IsDisabled="true">Disabled</BSNavItem>
</BSNav>