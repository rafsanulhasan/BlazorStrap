﻿<BSButtonGroup>
    <BSButton Color="BSColor.Primary">Left</BSButton>
    <BSButton Color="BSColor.Secondary">Middle</BSButton>
    <BSButton Color="BSColor.Success">Right</BSButton>
</BSButtonGroup>