<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Primary"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Secondary"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Success"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Danger"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Warning"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Info"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Light"/>
<BSSpinner SpinnerType="SpinnerType.Grow" Color="BSColor.Dark"/>