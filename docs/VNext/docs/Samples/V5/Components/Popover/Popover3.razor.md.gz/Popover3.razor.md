﻿<BSButton IsOutlined="true" Color="BSColor.Primary" DataId="contentpopoverLeft">Left</BSButton>
<BSPopover Placement="Placement.Left" Target="contentpopoverLeft" ContentAlwaysRendered="true">
    <Header>Left</Header>
    <Content>To the left</Content>
</BSPopover>
<BSButton IsOutlined="true" Color="BSColor.Primary" DataId="contentpopoverTop">Top</BSButton>
<BSPopover Placement="Placement.Top" Target="contentpopoverTop" MouseOver="true" ContentAlwaysRendered="true">
    <Header>Top</Header>
    <Content>Up top</Content>
</BSPopover>
<BSButton IsOutlined="true" Color="BSColor.Primary" DataId="contentpopoverBottom">Bottom</BSButton>
<BSPopover Placement="Placement.Bottom" Target="contentpopoverBottom" ContentAlwaysRendered="true">
    <Header>Bottom</Header>
    <Content>Down below</Content>
</BSPopover>
<BSButton IsOutlined="true" Color="BSColor.Primary" DataId="contentpopoverRight">Right</BSButton>
<BSPopover Placement="Placement.Right" Target="contentpopoverRight" ContentAlwaysRendered="true">
    <Header>Right</Header>
    <Content>To the right</Content>
</BSPopover>