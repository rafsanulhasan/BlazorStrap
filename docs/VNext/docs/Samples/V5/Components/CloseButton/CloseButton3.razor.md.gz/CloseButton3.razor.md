﻿<BSCloseButton IsWhite="true"/>
<BSCloseButton IsWhite="true" IsDisabled="true"/>