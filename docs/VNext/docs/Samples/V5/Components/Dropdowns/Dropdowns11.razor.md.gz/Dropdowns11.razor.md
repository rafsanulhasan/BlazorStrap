<BSButtonGroup DropdownPlacement="Placement.LeftStart">
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary" >Dropleft</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup DropdownPlacement="Placement.LeftStart">
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Secondary">Split dropright</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Secondary" IsSplitButton="true"><span class="visually-hidden">Toggle Dropleft</span></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>