<BSDropdown Demo="true">
    <Content>
        <BSDropdownItem>Regular link</BSDropdownItem>
        <BSDropdownItem IsDisabled="true">Disabled link</BSDropdownItem>
        <BSDropdownItem>Another link</BSDropdownItem>
    </Content>
</BSDropdown>