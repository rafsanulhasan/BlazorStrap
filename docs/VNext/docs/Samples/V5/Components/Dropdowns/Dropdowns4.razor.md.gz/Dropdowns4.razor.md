<!--\\-->
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Primary">Primary</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Primary" IsSplitButton="true"><span class="visually-hidden">Toggle Dropdown</span></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Secondary">Secondary</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Secondary" IsSplitButton="true"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Success">Success</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Success" IsSplitButton="true"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Info">Info</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Info" IsSplitButton="true"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Warning">Warning</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Warning" IsSplitButton="true"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<!--//-->
<!-- Example split Danger button -->
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSButton Color="BSColor.Danger">Danger</BSButton>
            <BSToggle IsButton="true" Color="BSColor.Danger" IsSplitButton="true"></BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
