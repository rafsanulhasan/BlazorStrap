<BSDropdown>
    <Toggler><BSToggle Class="btn btn-secondary">Dropdown link</BSToggle></Toggler>
    <Content>
        <BSDropdownItem>Action</BSDropdownItem>
        <BSDropdownItem>Another action</BSDropdownItem>
        <BSDropdownItem>Something else here</BSDropdownItem>
    </Content>
</BSDropdown>