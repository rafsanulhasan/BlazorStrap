<BSButtonGroup DropdownPlacement="Placement.BottomEnd">
<BSDropdown>
    <Toggler>
        <BSToggle IsButton="true" Color="BSColor.Secondary">Right-aligned menu example</BSToggle>
    </Toggler>
    <Content>
        <BSDropdownItem IsButton="true">Action</BSDropdownItem>
        <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
        <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
    </Content>
</BSDropdown>
</BSButtonGroup>