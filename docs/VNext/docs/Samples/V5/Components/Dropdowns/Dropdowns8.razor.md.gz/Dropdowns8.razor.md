<BSNavbar IsDark="true" Expand="Size.Large" Color="BSColor.Dark">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Navbar</BSNavbarBrand>
        <BSCollapse IsInNavbar="true">
            <Toggler>
                <BSNavbarToggle/>
            </Toggler>
            <Content>
                <BSNav>
                    <BSNavItem IsDropdown="true">
                        <BSDropdown IsDark="true">
                            <Toggler>
                                <BSToggle IsNavLink="true">Dropdown</BSToggle>
                            </Toggler>
                            <Content>
                                <BSDropdownItem>Action</BSDropdownItem>
                                <BSDropdownItem>Another action</BSDropdownItem>
                                <BSDropdownItem>Something else here</BSDropdownItem>
                            </Content>
                        </BSDropdown>
                    </BSNavItem>
                </BSNav>
            </Content>
        </BSCollapse>
    </BSContainer>
</BSNavbar>