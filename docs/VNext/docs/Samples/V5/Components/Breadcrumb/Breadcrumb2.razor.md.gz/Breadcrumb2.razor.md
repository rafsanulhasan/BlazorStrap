﻿<BSBreadcrumb Divider="'>'">
    <BSBreadcrumbItem Url="javascript:void(0);">Home</BSBreadcrumbItem>
    <BSBreadcrumbItem IsActive="true">Library</BSBreadcrumbItem>
</BSBreadcrumb>