﻿<BSBreadcrumb BasePath="/V5" Labels="Labels"/>
@code {
    private static readonly Dictionary<string,string> Labels = new()
    {
        // Full path
        {"/V5", "BlazorStrap V5"},
    };
}