﻿<BSModal DataId="modal7a" IsCentered="true" IsStaticBackdrop="true">
    <Header>Modal 1</Header>
    <Content>Hide this modal and show the second with the button below.</Content>
    <Footer>
        <BSButton MarginStart="Margins.Auto" Color="BSColor.Secondary" Target="modal7b">Open second modal</BSButton>
    </Footer>
</BSModal>
<BSModal DataId="modal7b" IsCentered="true">
    <Header>Modal 2</Header>
    <Content>Hide this modal and show the first with the button below.</Content>
    <Footer>
        <BSButton MarginStart="Margins.Auto" Color="BSColor.Secondary" Target="modal7a">Back to first</BSButton>
    </Footer>
</BSModal>
<BSButton Color="BSColor.Primary" Target="modal7a">Launch demo modal</BSButton>