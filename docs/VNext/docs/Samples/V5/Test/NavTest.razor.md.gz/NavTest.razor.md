﻿<BSNav IsTabs="true">
    <BSNavItem IsInitiallyActive="false">Test 1</BSNavItem>
    <BSNavItem IsInitiallyActive="false">Test 2</BSNavItem>
    <BSNavItem IsInitiallyActive="false">Test 3</BSNavItem>
    <BSNavItem IsInitiallyActive="true">Test 4</BSNavItem>
    <BSNavItem IsInitiallyActive="false">Test 5</BSNavItem>
</BSNav>