﻿<div Class="@BS.Form_Check">
    <BSInputCheckbox CheckedValue="@("nc")" Value="@("")" IsDisabled="true"/>
    <BSLabel IsCheckLabel="true">Disabled checkbox</BSLabel>
</div>
<div Class="@BS.Form_Check">
    <BSInputCheckbox CheckedValue="@("")" Value="@("")" IsDisabled="true"/>
    <BSLabel IsCheckLabel="true">Disabled checked checkbox</BSLabel>
</div>