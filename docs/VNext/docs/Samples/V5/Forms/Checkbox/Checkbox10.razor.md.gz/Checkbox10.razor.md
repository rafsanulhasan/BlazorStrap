﻿<BSInputCheckbox CheckedValue="@("Off")" UnCheckedValue="@("")" @bind-Value="Value" IsToggle="true" Color="BSColor.Primary" IsOutlined="true">
    Check 1
</BSInputCheckbox>
<BSColBreak/>
<BSInputCheckbox CheckedValue="@("On")" UnCheckedValue="@("")"@bind-Value="CheckValue" IsToggle="true" Color="BSColor.Secondary" IsOutlined="true">
    Check 2
</BSInputCheckbox>
<BSColBreak/>
<BSInputRadio CheckedValue="@("Radio 1")" @bind-Value="RadioValue" IsToggle="true" Color="BSColor.Success" IsOutlined="true">
    Radio 1
</BSInputRadio>
<BSInputRadio CheckedValue="@("Radio 2")" @bind-Value="RadioValue" IsToggle="true" Color="BSColor.Danger" IsOutlined="true">
    Radio 2
</BSInputRadio>
@code {
    private string Value { get; set; } = "";
    private string CheckValue { get; set; } = "";
    private string RadioValue { get; set; } = "";
}