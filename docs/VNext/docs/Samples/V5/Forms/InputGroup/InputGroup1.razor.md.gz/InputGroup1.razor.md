﻿<BSInputGroup MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text">@@</span>
    <BSInput InputType="InputType.Text" placeholder="Username"  Value="@("")"/>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInput InputType="InputType.Text" placeholder="Recipient's username"  Value="@("")"/>
    <span class="@BS.Input_Group_Text">@@example.com</span>
</BSInputGroup>

<BSLabel>Your vanity URL</BSLabel>
<BSInputGroup MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text" id="basic-addon3">https://example.com/users/</span>
    <BSInput InputType="InputType.Text"  Value="@("")"/>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text">$</span>
    <BSInput InputType="InputType.Text"  Value="@("")"/>
    <span class="@BS.Input_Group_Text">.00</span>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInput InputType="InputType.Text" placeholder="Username"  Value="@("")"/>
    <span class="@BS.Input_Group_Text" >@@</span>
    <BSInput InputType="InputType.Text" placeholder="Server"  Value="@("")"/>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text">With textarea</span>
    <BSInput InputType="InputType.TextArea"  Value="@("")"></BSInput>
</BSInputGroup>