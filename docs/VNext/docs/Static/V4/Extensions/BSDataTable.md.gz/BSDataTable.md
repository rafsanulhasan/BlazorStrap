﻿## BSDatatable
#### Component \<BlazorStrap.Extensions.BSDataTable\>
This is now a core component.
See [BSDataTable](Content/Tables) for additional details    
